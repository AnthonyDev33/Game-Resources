using Leopotam.Ecs;

namespace Game.Ecs.Components
{
    struct New : IEcsIgnoreInFilter
    {
    }
}
