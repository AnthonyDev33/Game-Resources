using Leopotam.Ecs;

namespace Client {
    struct Destroyed : IEcsIgnoreInFilter { }
}