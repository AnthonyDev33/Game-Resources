using Leopotam.Ecs;

namespace Game.Ecs.Components
{
    struct Created : IEcsIgnoreInFilter
    {
    }
}
