namespace Game.Ecs.Components
{
    public struct Bubble
    {
        public int Value;
    }
}
