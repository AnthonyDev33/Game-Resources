namespace Game.Ecs.Components
{
    struct Merge
    {
        public int Index;
    }
}
