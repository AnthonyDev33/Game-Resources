using UnityEngine;

namespace Game.Ecs.Components
{
    public struct Merging
    {
        public Vector2Int Target;
    }
}
