using Leopotam.Ecs;

namespace Game.Ecs.Components
{
    public struct InputReleased : IEcsIgnoreInFilter
    {
    }
}
