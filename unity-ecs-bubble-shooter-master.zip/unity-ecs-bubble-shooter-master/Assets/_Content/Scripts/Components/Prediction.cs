using Leopotam.Ecs;

namespace Game.Ecs.Components
{
    public struct Prediction : IEcsIgnoreInFilter
    {
    }
}
