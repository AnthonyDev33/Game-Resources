using Leopotam.Ecs;

namespace Game.Ecs.Components
{
    struct Connected : IEcsIgnoreInFilter
    {
    }
}
