using UnityEngine;

namespace Game.Ecs.Components
{
    public struct Position
    {
        public Vector2Int Value;
    }
}
