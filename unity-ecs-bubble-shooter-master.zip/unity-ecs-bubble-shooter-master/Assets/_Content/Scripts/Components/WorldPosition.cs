using UnityEngine;

namespace Game.Ecs.Components
{
    public struct WorldPosition
    {
        public Vector2 Value;
    }
}
