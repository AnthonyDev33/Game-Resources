namespace Game.Ecs.Components
{
    public struct Next
    {
        public int Index;
    }
}